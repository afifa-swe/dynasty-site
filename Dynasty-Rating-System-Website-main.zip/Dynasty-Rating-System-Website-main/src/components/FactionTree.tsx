import { useState, useRef, useMemo, useCallback, useEffect } from 'react';
import { User } from '../types/user';
import { ScrollCard } from './ScrollCard';
import { RealisticTree } from './RealisticTree';
import { ZoomIn, ZoomOut, Maximize2, ChevronRight, Info, X } from 'lucide-react';
import backgroundImage from 'figma:asset/9052ec8062b043d11876db1fa25ead193bb415c2.png';

const TREE_BASE_SIZE = 2400;
const INSTRUCTION_STORAGE_KEY = 'dynasty_tree_instructions_hidden';
const LEGENDARY_ROW_PATTERN = [3, 3];
const NOBLE_ROW_PATTERN = [4, 4, 4];
const TREASURE_ROW_PATTERN = [5];
const LEGENDARY_PER_SIDE = 6;
const NOBLE_PER_SIDE = 12;
const TREASURE_PER_SIDE = 22;

function splitIntoRows<T>(items: T[], pattern: number[], fallback: number) {
  const rows: T[][] = [];
  let index = 0;

  for (const count of pattern) {
    if (index >= items.length) break;
    rows.push(items.slice(index, index + count));
    index += count;
  }

  if (fallback <= 0) return rows;

  while (index < items.length) {
    rows.push(items.slice(index, index + fallback));
    index += fallback;
  }

  return rows;
}

interface FactionTreeProps {
  users: User[];
  onUserClick: (user: User) => void;
  newlyAddedUserIds?: string[];
  isMobile?: boolean;
}

export function FactionTree({
  users,
  onUserClick,
  newlyAddedUserIds,
  isMobile = false,
}: FactionTreeProps) {
  const defaultZoom = isMobile ? 0.25 : 0.5;
  const minZoom = isMobile ? 0.15 : 0.2;
  const mobileAutoZoomFloor = 0.25;

  const [zoom, setZoom] = useState(defaultZoom);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [touchStartDistance, setTouchStartDistance] = useState<number | null>(null);
  const [instructionCollapsed, setInstructionCollapsed] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const showDetails = zoom >= 0.4;
  const cardSize = isMobile ? 'sm' : 'md';
  const mobileControlsContainerClass = 'fixed flex flex-col gap-1.5 pointer-events-auto';
  const desktopControlsContainerClass = 'absolute top-4 right-4 flex gap-1.5 lg:gap-2 z-50 pointer-events-auto';
  const controlsContainerClass = isMobile ? mobileControlsContainerClass : desktopControlsContainerClass;
  const mobileControlButtonClass =
    'p-2 rounded-lg bg-slate-900/95 hover:bg-slate-800/95 active:bg-slate-700/95 text-white border border-amber-700/50 transition-all shadow-lg touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed';
  const desktopControlButtonClass =
    'p-2 lg:p-2.5 rounded-lg bg-slate-900/95 hover:bg-slate-800/95 active:bg-slate-700/95 text-white border border-amber-700/50 transition-all shadow-lg touch-manipulation disabled:opacity-40 disabled:cursor-not-allowed';
  const controlButtonClass = isMobile ? mobileControlButtonClass : desktopControlButtonClass;
  const mobileControlIconClass = 'w-4 h-4';
  const desktopControlIconClass = 'w-4 h-4 lg:w-5 lg:h-5';
  const controlIconClass = isMobile ? mobileControlIconClass : desktopControlIconClass;
  const tierLabelStyle = {
    fontFamily: 'Georgia, serif',
    backgroundColor: '#C9A961',
    color: '#2C1810',
    border: '2px solid #A0826D',
    padding: isMobile ? '0.375rem 1.5rem' : '0.5rem 2rem',
    fontSize: isMobile ? '0.875rem' : '1.25rem',
    letterSpacing: '0.05em',
  };
  const isNewlyAdded = useCallback(
    (userId: string) => (newlyAddedUserIds ? newlyAddedUserIds.includes(userId) : false),
    [newlyAddedUserIds],
  );
  const computeFitZoom = useCallback(() => {
    const container = containerRef.current;
    if (!container) return defaultZoom;

    const widthZoom = container.clientWidth / TREE_BASE_SIZE;
    const heightZoom = container.clientHeight / TREE_BASE_SIZE;
    const fitZoom = Math.min(widthZoom, heightZoom) * 0.9;
    const clampedFitZoom = isMobile ? Math.max(fitZoom, mobileAutoZoomFloor) : fitZoom;

    return Math.max(minZoom, Math.min(defaultZoom, clampedFitZoom || defaultZoom));
  }, [defaultZoom, isMobile, minZoom, mobileAutoZoomFloor]);
  const persistInstructionCollapsed = useCallback((collapsed: boolean) => {
    setInstructionCollapsed(collapsed);
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(INSTRUCTION_STORAGE_KEY, collapsed ? 'true' : 'false');
    } catch {
      // Ignore storage errors (private mode, storage disabled, etc.).
    }
  }, []);

  const sortedByFaction = useMemo(() => {
    const darkness = users.filter((user) => user.faction === 'darkness').sort((a, b) => b.rating - a.rating);
    const light = users.filter((user) => user.faction === 'light').sort((a, b) => b.rating - a.rating);
    return { darkness, light };
  }, [users]);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const stored = window.localStorage.getItem(INSTRUCTION_STORAGE_KEY);
      if (stored === 'true') {
        setInstructionCollapsed(true);
      }
    } catch {
      // Ignore storage errors.
    }
  }, []);
  const legendaryWinner = useMemo(() => {
    if (users.length === 0) return undefined;
    return users.reduce((best, user) => (best && best.rating >= user.rating ? best : user), users[0]);
  }, [users]);

  const perFactionBuckets = useMemo(() => {
    const winnerId = legendaryWinner?.id;
    const winnerFaction = legendaryWinner?.faction;
    const darknessList =
      winnerFaction === 'darkness' && winnerId
        ? sortedByFaction.darkness.filter((user) => user.id !== winnerId)
        : sortedByFaction.darkness;
    const lightList =
      winnerFaction === 'light' && winnerId
        ? sortedByFaction.light.filter((user) => user.id !== winnerId)
        : sortedByFaction.light;

    const legendaryDark = darknessList.slice(0, LEGENDARY_PER_SIDE);
    const legendaryLight = lightList.slice(0, LEGENDARY_PER_SIDE);

    const nobleStart = LEGENDARY_PER_SIDE;
    const nobleEnd = nobleStart + NOBLE_PER_SIDE;
    const nobleDark = darknessList.slice(nobleStart, nobleEnd);
    const nobleLight = lightList.slice(nobleStart, nobleEnd);

    const treasureStart = nobleEnd;
    const treasureEnd = treasureStart + TREASURE_PER_SIDE;
    const treasureDark = darknessList.slice(treasureStart, treasureEnd);
    const treasureLight = lightList.slice(treasureStart, treasureEnd);

    return {
      legendaryDark,
      legendaryLight,
      nobleDark,
      nobleLight,
      treasureDark,
      treasureLight,
    };
  }, [legendaryWinner, sortedByFaction]);

  const legendaryRows = {
    darkness: splitIntoRows(perFactionBuckets.legendaryDark, LEGENDARY_ROW_PATTERN, 0),
    light: splitIntoRows(perFactionBuckets.legendaryLight, LEGENDARY_ROW_PATTERN, 0),
  };

  const nobleRows = {
    darkness: splitIntoRows(perFactionBuckets.nobleDark, NOBLE_ROW_PATTERN, 0),
    light: splitIntoRows(perFactionBuckets.nobleLight, NOBLE_ROW_PATTERN, 0),
  };

  const treasureRows = {
    darkness: splitIntoRows(perFactionBuckets.treasureDark, TREASURE_ROW_PATTERN, 5),
    light: splitIntoRows(perFactionBuckets.treasureLight, TREASURE_ROW_PATTERN, 5),
  };

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY * -0.001;
    setZoom(z => Math.min(Math.max(minZoom, z + delta), 2.0));
  }, [minZoom]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button === 0) { // Left click only
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  }, [pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging) {
      // Use requestAnimationFrame for smooth panning
      requestAnimationFrame(() => {
        setPan({
          x: e.clientX - dragStart.x,
          y: e.clientY - dragStart.y,
        });
      });
    }
  }, [isDragging, dragStart]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const resetView = useCallback(() => {
    const targetZoom = isMobile ? computeFitZoom() : defaultZoom;
    setZoom(targetZoom);
    setPan({ x: 0, y: 0 });
  }, [computeFitZoom, defaultZoom, isMobile]);

  // Touch event handlers for mobile
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      // Single touch - pan
      setIsDragging(true);
      setDragStart({ 
        x: e.touches[0].clientX - pan.x, 
        y: e.touches[0].clientY - pan.y 
      });
    } else if (e.touches.length === 2) {
      // Two finger - prepare for pinch zoom
      const distance = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      setTouchStartDistance(distance);
    }
  }, [pan]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      // Single touch - pan
      setPan({
        x: e.touches[0].clientX - dragStart.x,
        y: e.touches[0].clientY - dragStart.y,
      });
    } else if (e.touches.length === 2 && touchStartDistance) {
      // Two finger - pinch zoom
      const currentDistance = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const delta = (currentDistance - touchStartDistance) * 0.01;
      setZoom(z => Math.min(Math.max(minZoom, z + delta), 2.0));
      setTouchStartDistance(currentDistance);
    }
  }, [isDragging, dragStart, touchStartDistance, minZoom]);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
    setTouchStartDistance(null);
  }, []);

  // Memoize transform styles
  const backgroundTransform = useMemo(() => ({
    transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
  }), [pan.x, pan.y, zoom]);

  const treeContainerTransform = useMemo(() => ({
    transform: `translate(calc(-50% + ${pan.x}px), calc(-50% + ${pan.y}px)) scale(${zoom})`,
  }), [pan.x, pan.y, zoom]);
  const zoomLabel = `Zoom: ${Math.round(zoom * 100)}%`;
  const instructionText = isMobile
    ? `${zoomLabel} · Names show at 40%+`
    : `Drag to pan - Wheel or buttons to zoom - ${zoomLabel} - Zoom in for names`;

  // Auto-fit the tree on initial load and when switching to mobile/tablet so it stays in view
  useEffect(() => {
    if (!isMobile) {
      setZoom(defaultZoom);
      setPan({ x: 0, y: 0 });
      return;
    }

    const updateZoomToFit = () => {
      setZoom(computeFitZoom());
      setPan({ x: 0, y: 0 });
    };

    updateZoomToFit();
    window.addEventListener('resize', updateZoomToFit);
    return () => window.removeEventListener('resize', updateZoomToFit);
  }, [computeFitZoom, defaultZoom, isMobile]);

  return (
    <div 
      ref={containerRef}
      className={`relative w-full h-full overflow-hidden ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Solid Background Colors - Burgundy left, Off-white right - Extends infinitely */}
      <div
        className="absolute pointer-events-none"
        style={{
          width: '1000vw',
          height: '1000vh',
          left: '50%',
          top: '50%',
          marginLeft: '-500vw',
          marginTop: '-500vh',
          background: 'linear-gradient(to right, #730705 0%, #730705 50%, #f3f3f3 50%, #f3f3f3 100%)',
          ...backgroundTransform,
          transformOrigin: 'center center',
        }}
      />
      
      {/* Background Image - Repeats vertically with seamless tiling */}
      <div
        className="absolute pointer-events-none"
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'auto 2800px',
          backgroundPosition: 'center top',
          backgroundRepeat: 'repeat-y',
          width: '1000vw',
          height: '1000vh',
          left: '50%',
          top: '50%',
          marginLeft: '-500vw',
          marginTop: '-500vh',
          ...backgroundTransform,
          transformOrigin: 'center center',
        }}
      />

      {/* Controls */}
      <div
        className={controlsContainerClass}
        style={isMobile ? { top: 10, left: 10, zIndex: 30 } : undefined}
      >
        <button
          onClick={() => setZoom(Math.min(zoom + 0.1, 2.0))}
          className={controlButtonClass}
          title="Zoom In"
        >
          <ZoomIn className={controlIconClass} />
        </button>
        <button
          onClick={() => setZoom(Math.max(zoom - 0.1, minZoom))}
          className={controlButtonClass}
          title="Zoom Out"
        >
          <ZoomOut className={controlIconClass} />
        </button>
        <button
          onClick={resetView}
          className={controlButtonClass}
          title="Reset View"
        >
          <Maximize2 className={controlIconClass} />
        </button>
        {isMobile && instructionCollapsed && (
          <button
            type="button"
            onClick={() => persistInstructionCollapsed(false)}
            className={controlButtonClass}
            title="Show instructions"
          >
            <Info className={controlIconClass} />
          </button>
        )}
      </div>

      {/* Instructions */}
      {!instructionCollapsed && (
        <div
          className={`absolute top-4 pointer-events-none ${
            isMobile
              ? 'left-1/2 -translate-x-1/2'
              : 'left-4 right-44 flex justify-center'
          }`}
          style={isMobile ? { zIndex: 40 } : { zIndex: 2 }}
        >
          <div className="max-w-full px-3 lg:px-4 py-1.5 lg:py-2 rounded-lg bg-slate-900/95 text-amber-400 border border-amber-700/50 shadow-lg backdrop-blur-sm pointer-events-auto">
            <div className="flex items-center gap-2">
              <span
                className={`min-w-0 text-center ${
                  isMobile ? 'text-[11px] whitespace-nowrap' : 'text-xs lg:text-sm leading-tight'
                }`}
              >
                {instructionText}
              </span>
              {isMobile ? (
                <button
                  type="button"
                  onClick={() => persistInstructionCollapsed(true)}
                  className="p-1 rounded-md bg-black/30 hover:bg-black/50 border border-amber-700/40 text-amber-200"
                  aria-label="Hide instructions"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => persistInstructionCollapsed(true)}
                  className="px-2 py-0.5 text-[10px] lg:text-xs rounded-md bg-black/30 hover:bg-black/50 border border-amber-700/40 text-amber-200"
                >
                  Hide
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      {!isMobile && instructionCollapsed && (
        <button
          type="button"
          onClick={() => persistInstructionCollapsed(false)}
          className="absolute top-4 left-4 p-1.5 rounded-md bg-slate-900/95 border border-amber-700/50 text-amber-200 shadow-lg hover:bg-slate-800/95"
          style={{ zIndex: 2 }}
          title="Show instructions"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      )}

      {/* Tree Container - Centered and Draggable */}
      <div
        className="absolute left-1/2 top-1/2 pointer-events-none"
        style={{
          ...treeContainerTransform,
          transformOrigin: 'center center',
          width: '100%',
          zIndex: 1,
        }}
      >
        <div className="relative pointer-events-auto" style={{ width: '100%', paddingTop: '20px', paddingBottom: '200px', marginLeft: isMobile ? '-8px' : '0' }}>
          {/* Dynasty Title - Split Color - Centered - Above Tree */}
          <div className="absolute text-center" style={{ height: isMobile ? '50px' : '80px', zIndex: 100, top: isMobile ? '-200px' : '-300px', left: '50%', transform: 'translateX(-50%)', width: '100%' }}>
            <div className="flex items-center justify-center overflow-hidden h-full">
              <h1 
                style={{ 
                  fontFamily: 'Georgia, serif',
                  fontWeight: 'bold',
                  fontSize: isMobile ? '2.5rem' : '4.5rem',
                  letterSpacing: '0.1em',
                  background: 'linear-gradient(to right, #C9A961 0%, #C9A961 50%, #2C1810 50%, #2C1810 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  textShadow: 'none',
                }}
              >
                DYNASTY
              </h1>
            </div>
          </div>

          {/* Faction Labels - Above Tree */}
          <div className="absolute flex justify-between" style={{ zIndex: 100, top: isMobile ? '-120px' : '-180px', left: '0', right: '0', paddingLeft: isMobile ? '2rem' : '10rem', paddingRight: isMobile ? '2rem' : '10rem' }}>
            <div 
              style={{ 
                fontFamily: 'Georgia, serif',
                fontSize: isMobile ? '1.25rem' : '1.875rem',
                letterSpacing: isMobile ? '0.1em' : '0.15em',
                color: '#C9A961',
                textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
              }}
            >
              DARKNESS
            </div>
            <div 
              style={{ 
                fontFamily: 'Georgia, serif',
                fontSize: isMobile ? '1.25rem' : '1.875rem',
                letterSpacing: isMobile ? '0.1em' : '0.15em',
                color: '#2C1810',
                textShadow: '2px 2px 4px rgba(255,255,255,0.3)',
              }}
            >
              LIGHT
            </div>
          </div>

          {/* Tree SVG Background */}
          <RealisticTree />

          {/* Scrolls positioned on tree */}
          <div className="relative" style={{ zIndex: 10 }}>
            {/* LEGENDARY TIER - Top ranked members near the canopy */}
            <div className="relative mb-12" style={{ zIndex: 10, paddingTop: isMobile ? '10px' : '20px' }}>
              <div className="flex justify-center mb-10">
                <div style={tierLabelStyle}>LEGENDARY</div>
              </div>

              {legendaryWinner ? (
                <div className="flex items-center justify-center mb-16">
                  <ScrollCard
                    user={legendaryWinner}
                    onClick={() => onUserClick(legendaryWinner)}
                    index={0}
                    isNewlyAdded={isNewlyAdded(legendaryWinner.id)}
                    showDetails={showDetails}
                    size={cardSize}
                  />
                </div>
              ) : null}

              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'flex-start',
                  gap: '8rem',
                }}
              >
                <div
                  className="flex flex-col"
                  style={{
                    gap: '60px',
                    width: '700px',
                    maxWidth: '700px',
                  }}
                >
                  {legendaryRows.darkness.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`legendary-dark-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: '60px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>

                <div
                  className="flex flex-col"
                  style={{
                    gap: '60px',
                    width: '700px',
                    maxWidth: '700px',
                  }}
                >
                  {legendaryRows.light.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`legendary-light-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: '60px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>
              </div>
            </div>

            {/* NOBLE CIRCLE TIER - Upper-mid members per faction - On lower branches transitioning to roots */}
            <div className="relative mb-12" style={{ zIndex: 10, paddingTop: isMobile ? '10px' : '20px' }}>
              <div className="flex justify-center mb-10">
                <div style={tierLabelStyle}>NOBLE CIRCLE</div>
              </div>

              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'flex-start',
                  gap: '8rem',
                }}
              >
                <div
                  className="flex flex-col"
                  style={{
                    gap: '60px',
                    width: '800px',
                    maxWidth: '800px',
                  }}
                >
                  {nobleRows.darkness.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`noble-dark-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: '60px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>

                <div
                  className="flex flex-col"
                  style={{
                    gap: '60px',
                    width: '800px',
                    maxWidth: '800px',
                  }}
                >
                  {nobleRows.light.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`noble-light-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: '60px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>
              </div>
            </div>

            {/* TREASURE HUNTERS TIER - All other members - On roots at bottom */}
            <div className="relative mb-12" style={{ zIndex: 10, paddingTop: isMobile ? '30px' : '20px' }}>
              <div className="flex justify-center mb-10">
                <div style={tierLabelStyle}>TREASURE HUNTERS</div>
              </div>

              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'flex-start',
                  gap: isMobile ? '7rem' : '5rem',
                  marginTop: '0',
                }}
              >
                <div
                  className="flex flex-col"
                  style={{
                    gap: '55px',
                    width: isMobile ? '1000px' : '1100px',
                    maxWidth: isMobile ? '1000px' : '1100px',
                  }}
                >
                  {treasureRows.darkness.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`treasure-dark-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: rowIndex < 3 ? '35px' : '45px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>

                <div
                  className="flex flex-col"
                  style={{
                    gap: '55px',
                    width: isMobile ? '1000px' : '1100px',
                    maxWidth: isMobile ? '1000px' : '1100px',
                  }}
                >
                  {treasureRows.light.map((row, rowIndex) =>
                    row.length ? (
                      <div
                        key={`treasure-light-${rowIndex}`}
                        className="flex items-center justify-center"
                        style={{ gap: rowIndex < 3 ? '35px' : '45px' }}
                      >
                        {row.map((user, index) => (
                          <div key={user.id}>
                            <ScrollCard
                              user={user}
                              onClick={() => onUserClick(user)}
                              index={rowIndex * 4 + index}
                              isNewlyAdded={isNewlyAdded(user.id)}
                              showDetails={showDetails}
                              size={cardSize}
                            />
                          </div>
                        ))}
                      </div>
                    ) : null,
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
