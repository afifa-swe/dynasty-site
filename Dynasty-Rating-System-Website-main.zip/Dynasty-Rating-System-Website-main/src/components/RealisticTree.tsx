import { memo } from 'react';
import { motion } from 'motion/react';
import treeImage from 'figma:asset/7a0ac26a85cc417665b38254884871dd22d5b86b.png';

export const RealisticTree = memo(function RealisticTree() {
  return (
    <div 
      className="absolute left-1/2 transform -translate-x-1/2 pointer-events-none"
      style={{ 
        zIndex: 1,
        width: '2400px',
        height: '2400px',
        top: '-200px',
        willChange: 'transform',
      }}
    >
      {/* Animated multi-layer glow effect - pulsating and breathing */}
      <div className="absolute inset-0">
        {/* Outer glow layer - soft and wide with slow pulse */}
        <motion.img 
          src={treeImage}
          alt=""
          className="absolute w-full h-full object-contain"
          style={{
            filter: 'brightness(0.5) saturate(0.9) blur(60px) drop-shadow(0 0 70px rgba(251, 191, 36, 0.5)) drop-shadow(0 0 90px rgba(252, 211, 77, 0.4))',
          }}
          animate={{
            opacity: [0.5, 0.7, 0.5],
            scale: [1, 1.02, 1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          loading="eager"
          aria-hidden="true"
        />
        
        {/* Middle glow layer - medium spread with offset timing */}
        <motion.img 
          src={treeImage}
          alt=""
          className="absolute w-full h-full object-contain"
          style={{
            filter: 'brightness(0.45) saturate(0.85) blur(35px) drop-shadow(0 0 50px rgba(245, 158, 11, 0.6)) drop-shadow(0 0 60px rgba(251, 191, 36, 0.5))',
          }}
          animate={{
            opacity: [0.6, 0.8, 0.6],
            scale: [1, 1.015, 1],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 0.5,
          }}
          loading="eager"
          aria-hidden="true"
        />
        
        {/* Inner glow layer - concentrated with faster pulse */}
        <motion.img 
          src={treeImage}
          alt=""
          className="absolute w-full h-full object-contain"
          style={{
            filter: 'brightness(0.4) saturate(0.8) blur(15px) drop-shadow(0 0 40px rgba(253, 224, 71, 0.65)) drop-shadow(0 0 30px rgba(252, 211, 77, 0.6))',
          }}
          animate={{
            opacity: [0.7, 0.9, 0.7],
            scale: [1, 1.01, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 1,
          }}
          loading="eager"
          aria-hidden="true"
        />
      </div>
      
      {/* Main tree image - crisp with shadow */}
      <img 
        src={treeImage}
        alt="Dynasty Tree"
        className="relative w-full h-full object-contain"
        style={{
          opacity: 0.85,
          filter: 'brightness(0.4) saturate(0.8) drop-shadow(0 4px 20px rgba(0,0,0,0.5))',
          zIndex: 2,
        }}
        loading="eager"
      />
    </div>
  );
});
