import { memo } from 'react';
import { User } from '../types/user';
import { motion } from 'motion/react';

interface ScrollCardProps {
  user: User;
  onClick: () => void;
  index?: number;
  isNewlyAdded?: boolean;
  showDetails?: boolean;
  size?: 'md' | 'sm';
}

export const ScrollCard = memo(function ScrollCard({
  user,
  onClick,
  index = 0,
  isNewlyAdded = false,
  showDetails = true,
  size = 'md',
}: ScrollCardProps) {
  const isDarkness = user.faction === 'darkness';
  const isCompact = size === 'sm';
  const cardWidth = isCompact ? 128 : 152;
  const cardHeight = isCompact ? 96 : 114;
  const baseNameSize = isCompact ? 11 : 13;
  const nameLength = user.nickname.length;
  const overflowChars = Math.max(0, nameLength - (isCompact ? 10 : 12));
  const shrinkSteps = Math.min(3, Math.floor(overflowChars / 3));
  const nameSize = `${Math.max(baseNameSize - shrinkSteps, isCompact ? 10 : 12)}px`;
  const ratingSize = isCompact ? '12px' : '14px';
  const ptsSize = isCompact ? '10px' : '12px';

  return (
    <motion.div
      layout
      initial={isNewlyAdded ? { opacity: 0, scale: 0, y: -50, rotate: -10 } : { opacity: 0, scale: 0.8, y: -20, rotate: 0 }}
      animate={isNewlyAdded ? { opacity: 1, scale: 1, y: 0, rotate: 0 } : { opacity: 1, scale: 1, y: 0, rotate: 0 }}
      transition={isNewlyAdded 
        ? { delay: 0.2, type: 'spring', stiffness: 200, damping: 15 } 
        : { delay: index * 0.05, type: 'spring', stiffness: 100 }
      }
      whileHover={{ scale: 1.05, y: -3 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="relative cursor-pointer group touch-manipulation"
      style={{ width: `${cardWidth}px`, height: `${cardHeight}px`, willChange: 'transform' }}
    >
      {/* Scroll shadow for depth */}
      <div className="absolute inset-0 bg-black/50 blur-lg transform translate-y-3" style={{ willChange: 'transform' }}></div>
      
      {/* Scroll background */}
      <div className="relative">
        {/* Simplified Scroll SVG - Reusable gradients */}
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 160 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-2xl w-full h-full"
        >
          {/* Scroll Paper Body with Darker Texture */}
          <defs>
            <linearGradient id={`scrollGrad${user.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={isDarkness ? '#3D2F24' : '#7A6A54'} />
              <stop offset="50%" stopColor={isDarkness ? '#2E2419' : '#635446'} />
              <stop offset="100%" stopColor={isDarkness ? '#1F1810' : '#4D4035'} />
            </linearGradient>
          </defs>
          
          {/* Main scroll body */}
          <rect
            x="15"
            y="20"
            width="130"
            height="80"
            fill={`url(#scrollGrad${user.id})`}
            stroke={isDarkness ? '#1A130E' : '#2E2419'}
            strokeWidth="2"
            rx="1"
          />
          
          {/* Left Roll - Dark Wood */}
          <g>
            <rect x="8" y="20" width="14" height="80" fill={isDarkness ? '#2E2419' : '#3D2F24'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="2"/>
            <line x1="10" y1="25" x2="20" y2="25" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <line x1="10" y1="55" x2="20" y2="55" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <line x1="10" y1="85" x2="20" y2="85" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <rect x="8" y="35" width="14" height="3" fill={isDarkness ? '#1A130E' : '#221A13'} opacity="0.6"/>
            <rect x="8" y="82" width="14" height="3" fill={isDarkness ? '#1A130E' : '#221A13'} opacity="0.6"/>
            <ellipse cx="15" cy="20" rx="7" ry="3.5" fill={isDarkness ? '#3D2F24' : '#4D4035'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="1.5"/>
            <ellipse cx="15" cy="100" rx="7" ry="3.5" fill={isDarkness ? '#221A13' : '#2E2419'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="1.5"/>
          </g>
          
          {/* Right Roll - Dark Wood */}
          <g>
            <rect x="138" y="20" width="14" height="80" fill={isDarkness ? '#2E2419' : '#3D2F24'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="2"/>
            <line x1="140" y1="25" x2="150" y2="25" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <line x1="140" y1="55" x2="150" y2="55" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <line x1="140" y1="85" x2="150" y2="85" stroke={isDarkness ? '#1A130E' : '#2A1F17'} strokeWidth="0.5" opacity="0.4"/>
            <rect x="138" y="35" width="14" height="3" fill={isDarkness ? '#1A130E' : '#221A13'} opacity="0.6"/>
            <rect x="138" y="82" width="14" height="3" fill={isDarkness ? '#1A130E' : '#221A13'} opacity="0.6"/>
            <ellipse cx="145" cy="20" rx="7" ry="3.5" fill={isDarkness ? '#3D2F24' : '#4D4035'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="1.5"/>
            <ellipse cx="145" cy="100" rx="7" ry="3.5" fill={isDarkness ? '#221A13' : '#2E2419'} stroke={isDarkness ? '#1A130E' : '#2E2419'} strokeWidth="1.5"/>
          </g>
          
          {/* Inner border */}
          <rect
            x="20"
            y="25"
            width="120"
            height="70"
            fill="none"
            stroke={isDarkness ? '#8B6914' : '#5A4A2A'}
            strokeWidth="0.5"
            opacity="0.3"
            rx="1"
          />
          
          {/* Wax seal (for top ranked) */}
          {showDetails && user.rank <= 10 && user.tier === 'legendary' && (
            <g>
              <circle cx="142" cy="26" r="9" fill="#5C0000" opacity="0.95"/>
              <circle cx="142" cy="26" r="7" fill="#7A0000" opacity="0.8"/>
              <circle cx="142" cy="26" r="5" fill="#8B0000" opacity="0.7"/>
              <text x="142" y="29" textAnchor="middle" fill="#B8860B" fontSize="7" fontWeight="bold">★</text>
            </g>
          )}
        </svg>

        {/* Content overlay */}
        {showDetails && (
          <>
            <div className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              <div className="px-2 py-1 rounded-md bg-slate-900/90 text-[10px] text-amber-200 border border-amber-500/30 shadow-lg max-w-[220px] whitespace-normal text-center">
                {user.nickname}
              </div>
            </div>
            <div className="absolute inset-0 flex flex-col items-center justify-center px-4 pt-2">
              <div
                className="text-center truncate w-full px-2 mb-1"
                title={user.nickname}
                style={{
                  fontFamily: 'Georgia, serif',
                  fontSize: nameSize,
                  fontWeight: '600',
                  color: isDarkness ? '#C9A961' : '#DAA520',
                  textShadow: isDarkness 
                    ? '0 2px 6px rgba(0,0,0,0.9), 0 0 15px rgba(201,169,97,0.4)' 
                    : '0 2px 6px rgba(0,0,0,0.8), 0 0 12px rgba(218,165,32,0.3)',
                  letterSpacing: '0.5px',
                }}
              >
                {user.nickname}
              </div>
            <div
              className="mt-1"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: ratingSize,
                fontWeight: 'bold',
                color: isDarkness ? '#B8860B' : '#CD9B1D',
                textShadow: '0 2px 4px rgba(0,0,0,0.8)',
              }}
            >
              {user.rating.toLocaleString()}
            </div>
            <div
              className="text-xs mt-0.5"
              style={{
                fontFamily: 'Georgia, serif',
                fontSize: ptsSize,
                color: isDarkness ? '#8B6914' : '#9A7B1A',
                opacity: 0.7,
              }}
            >
              pts
            </div>
            </div>
          </>
        )}

        {/* Rank badge */}
        {showDetails && user.rank <= 10 && user.tier === 'legendary' && (
          <div className={`absolute -top-2 -right-2 ${isCompact ? 'w-7 h-7' : 'w-9 h-9'} rounded-full bg-gradient-to-br from-amber-600 via-amber-700 to-amber-900 border-2 border-amber-950 flex items-center justify-center shadow-xl`}>
            <div className={`text-amber-200 font-bold ${isCompact ? 'text-[10px]' : 'text-xs'}`} style={{ fontFamily: 'Georgia, serif' }}>#{user.rank}</div>
          </div>
        )}

        {/* Subtle glow on hover */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-900/10 to-amber-950/10 rounded-lg blur-lg"></div>
        </div>

        {/* Special GOLDEN glow effect for Rank #1 - Optimized */}
        {user.rank === 1 && user.tier === 'legendary' && (
          <motion.div
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="absolute pointer-events-none"
            style={{
              inset: '-40px',
              willChange: 'opacity',
            }}
          >
            {/* Simplified glow - fewer layers */}
            <div 
              className="absolute"
              style={{
                left: '50%',
                top: '50%',
                width: '180%',
                height: '180%',
                transform: 'translate(-50%, -50%)',
                background: 'radial-gradient(ellipse at center, transparent 30%, rgba(251, 191, 36, 0.25) 60%, rgba(245, 158, 11, 0.2) 80%, transparent 100%)',
                filter: 'blur(20px)',
                borderRadius: '50%',
              }}
            ></div>
            <div 
              className="absolute"
              style={{
                left: '50%',
                top: '50%',
                width: '120%',
                height: '120%',
                transform: 'translate(-50%, -50%)',
                background: 'radial-gradient(ellipse at center, transparent 40%, rgba(253, 224, 71, 0.4) 70%, rgba(252, 211, 77, 0.3) 90%, transparent 100%)',
                filter: 'blur(10px)',
                borderRadius: '50%',
              }}
            ></div>
          </motion.div>
        )}

        {/* Special glow effect for newly added users */}
        {isNewlyAdded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{ duration: 3, times: [0, 0.1, 0.8, 1] }}
            className="absolute inset-0 pointer-events-none"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/40 via-pink-500/40 to-amber-500/40 rounded-lg blur-xl"></div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
});
